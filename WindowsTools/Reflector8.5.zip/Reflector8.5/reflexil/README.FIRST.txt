Dear Reflector users:

This Reflexil version works from Reflector v6.8.2.5 to 8.3.0.95

--

For Reflector, JustDecompile and CecilStudio users, you can visit the following page to get extra infos :

http://www.codeproject.com/KB/msil/reflexil.aspx

--
Regards
Sebastien LEBRETON
